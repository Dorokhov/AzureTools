﻿exports.create = function (redisClientFactory, $redisSettings) {
    'use strict';

    return new function() {
        var self = this;
        self.oTable = null;
        self.showKeys = function (keys) {
            var client = redisClientFactory($redisSettings.Host, $redisSettings.Port, $redisSettings.Password);
            
            if (self.oTable) {
                self.oTable.draw();
                return;
            }

            self.oTable = $('#data').DataTable({
                bFilter: false,
                bInfo: false,
                bPaginate: false,

                "data": keys,
                "columns": [
                    { "title": "Key" },
                ]
            });

            function format(d) {
                return 'Full name: ' + d.first_name + ' ' + d.last_name + '<br>' +
                    'Salary: ' + d.salary + '<br>' +
                    'The child row can contain any data you wish, including links, images, inner tables etc.';
            }

            $('#data tbody').on('click', 'tr', function () {

                var tr = $(this).closest('tr');
                var row = oTable.row(tr);

                if (row.child.isShown()) {
                    // This row is already open - close it
                    row.child.hide();
                    tr.removeClass('shown');
                } else {
                    // Open this row
                    client.get(row.data(), function (e, value) {
                        row.child(value).show();
                        tr.addClass('shown');
                    });
                }
            });
        }
    }
}