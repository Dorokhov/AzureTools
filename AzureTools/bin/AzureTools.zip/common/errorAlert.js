﻿exports.create = function(email) {
    'use strict';
    var self = this;
    self.Email = email;
    return function() {}
};