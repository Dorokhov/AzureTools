﻿exports.create = function (redisClientFactory, dataTablePresenter, $actionBarItems, $dialogViewModel, $redisSettings) {
    'use strict';

    return new function() {
        var self = this;
        var client = redisClientFactory($redisSettings.Host, $redisSettings.Port, $redisSettings.Password);

        $actionBarItems.IsActionBarVisible = true;
        $actionBarItems.IsAddKeyVisible = true;
        $actionBarItems.IsRefreshVisible = true;
        $actionBarItems.IsSettingsVisible = true;

        $actionBarItems.addKey = function () {
            client.add();
            $dialogViewModel.IsVisible = true;
            $dialogViewModel.BodyViewModel = $redisSettings;
            $dialogViewModel.Body = 'createKeyTemplate';
            $dialogViewModel.Header = 'Add Key';
        };
        $actionBarItems.refresh = function() {
            self.loadKeys();
        };
        $actionBarItems.changeSettings = function() {
            $dialogViewModel.IsVisible = true;
            $dialogViewModel.BodyViewModel = $redisSettings;
            $dialogViewModel.Body = 'changeSettingsTemplate';
            $dialogViewModel.Header = 'Settings';
        };

        self.loadKeys = function() {
            client.keys('*', function (err, keys) {
                if (err) {
                    console.log(err);
                }

                dataTablePresenter.showKeys(keys);
            });
        };

        self.loadKeys();
    }
}