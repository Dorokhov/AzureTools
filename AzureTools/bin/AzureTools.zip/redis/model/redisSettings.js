﻿exports.create = function() {
    'use strict';

    return new function() {
        'use strict';

        var self = this;

        self.Host = 'redisdor.redis.cache.windows.net';
        self.Port = 6379;
        self.Password = 'ZaVlBh0AHJmw2r3PfWVKvm7X3FfC5fe+sMKJ93RueNY=';
    }
};