beefy (v2.1.5) is listening on http://127.0.0.1:9966
200   13ms       489B  /
200   13ms       174B  /content/css/grid.css
200   14ms    17.45KB  /node_modules/datatables/media/css/jquery.dataTables.css
200   14ms        78B  /bundle.js
200    9ms       489B  /
200    3ms       174B  /content/css/grid.css
200    3ms    17.45KB  /node_modules/datatables/media/css/jquery.dataTables.css
200    3ms       262B  /bundle.js
